<?php 
	
	include('header.php');
	
	echo $_GET['id'];
	//user.txt
	----------

	//header('location: userlist.php');

?>