<?php
	if(!isset($_COOKIE['flag'])){
		header('location: login.html');
	}
?>